export const inputFormElements14 = [
//     {
//         name: "CompanyId",
//         label: "CompanyId",
//         variant: "outlined",
//         fullWidth: true,
//         required: true,
//         xs: 12,
//         sm: 12,
        
//     },
// {
//     name: "BranchId",
//     label: "BranchId", 
//     variant: "outlined", 
//     fullWidth: true,
//     required: true,
//     xs:12, 
//     sm:12,
// // },
// {
//     name: "ShiftCode",
//     label: "ShifrCode", 
//     variant: "outlined", 
//     fullWidth: true,
//     required: true,
//     xs:12, 
//     sm:12,
// },
// {
//     name: "StartTime",
//     label: "StartTime", 
//     variant: "outlined", 
//     fullWidth: true,
//     required: true,
//     xs:12, 
//     sm:12,
//     type:"datetime-local"
// },
// {
//     name: "BreakTimeOut",
//     label: "BreakTimeOut", 
//     variant: "outlined", 
//     fullWidth: true,
//     required: true,
//     xs:12, 
//     sm:12,
//     type:"datetime-local"
// },
// {
//     name: "BreakTimeIn",
//     label: "BreakTimeIn", 
//     variant: "outlined", 
//     fullWidth: true,
//     required: true,
//     xs:12, 
//     sm:12,
//     type:"datetime-local"
// },
// {
//     name: "EndTime",
//     label: "EndTime", 
//     variant: "outlined", 
//     fullWidth: true,
//     required: true,
//     xs:12, 
//     sm:12,
//     type:"datetime-local"
// },
// {
//     name: "ShiftIndicator",
//     label: "Shift Indicator", 
//     variant: "outlined", 
//     fullWidth: true,
//     required: true,
//     xs:12, 
//     sm:12,
// },



]
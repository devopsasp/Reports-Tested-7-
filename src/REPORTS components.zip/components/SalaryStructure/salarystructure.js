// export const inputFormElements16 = [
    

// {
//     name: "salary",
//     label: "Salary", 
//     variant: "outlined", 
//     fullWidth: true,
//     required: true,
//     xs:12, 
//     sm:12,
// },

// {
//     name: "effectiveDate",
//     label: "EffectiveDate", 
//     variant: "outlined", 
//     fullWidth: true,
//     required: true,
//     xs:12, 
//     sm:12,
//     type:"datetime-local"
// },

// {
//     name: "remarks",
//     label: "Remarks", 
//     variant: "outlined", 
//     fullWidth: true,
//     required: true,
//     xs:12, 
//     sm:12,
// },

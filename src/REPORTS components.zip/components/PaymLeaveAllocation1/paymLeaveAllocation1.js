export const inputpaymleaveAllocation1Form= [
    
    {
        name:"PnCompanyId",
        placeholder:"Enter Company Id ",
        label:"Company Id",
        variant:"outlined",
        fullWidth:true,
        required:true,
        
        xs:12,sm:12,
        select:true, 
            options: [
                {value:"1", lable:"Company 1"},
                {value:"2", lable:"Company 2"}
            ]
       
        },
        {
            name:"pn_branchid",
            placeholder:"Enter Pn Branch ID ",
            label:"Pn Branch ID",
            variant:"outlined",
            fullWidth:true,
            required:true,
            
            xs:12,sm:12,
           
           
            },
            {
                name:"pn_leaveid",
                placeholder:"pn Leave Id",
                label:"pn Leave Id",
                variant:"outlined",
                fullWidth:true,
                required:true,
                
                xs:12,sm:12,
                
                },

                {
                    name:"pn_employeeid",
                    placeholder:"pn Employee Id",
                    label:"pn Employee Id",
                    variant:"outlined",
                    fullWidth:true,
                    required:true,
                    
                    xs:12,sm:12,
                    
                    },

                    {
                        name:"n_count",
                        placeholder:"n Count",
                        label:"n Count",
                        variant:"outlined",
                        fullWidth:true,
                        required:true,
                        
                        xs:12,sm:12,
                        
                        },

                        {
                            name:"cy_count",
                            placeholder:"cy Count",
                            label:"cy Count",
                            variant:"outlined",
                            fullWidth:true,
                            required:true,
                            
                            xs:12,sm:12,
                            
                            },

                            {
                                name:"Leaveby",
                                placeholder:"LeaveBy",
                                label:"LeaveBy",
                                variant:"outlined",
                                fullWidth:true,
                                required:true,
                                
                                xs:12,sm:12,
                                
                                },

                                {
                                    name:"yearend",
                                    placeholder:"yearend",
                                    label:"yearend",
                                    variant:"outlined",
                                    fullWidth:true,
                                    required:true,
                                    
                                    xs:12,sm:12,
                                    
                                    },
                ]

                   
export const inputpaymEncashmentDetailsForm= [
    
    {
        name:"PnCompanyId",
        placeholder:"Enter Company Id ",
        label:"Company Id",
        variant:"outlined",
        fullWidth:true,
        required:true,
        
        xs:12,sm:12,
       
        },
        {
            name:"pn_BranchID",
            placeholder:"Enter pn  Branch ID ",
            label:"pn Branch ID",
            variant:"outlined",
            fullWidth:true,
            required:true,
            
            xs:12,sm:12,
           
           
            },
            {
                name:"pn_EmployeeID",
                placeholder:"Employee ID ",
                label:"Employee ID",
                variant:"outlined",
                fullWidth:true,
                required:true,
                
                xs:12,sm:12,
                
                },

                {
                    name:"Pn_LeaveId",
                    placeholder:"Leave ID ",
                    label:"Leave ID",
                    variant:"outlined",
                    fullWidth:true,
                    required:true,
                    
                    xs:12,sm:12,
                    
                    },

                    {
                        name:"Allow_Days",
                        placeholder:"Allow Days",
                        label:"Allow Days",
                        variant:"outlined",
                        fullWidth:true,
                        required:true,
                        
                        xs:12,sm:12,
                        
                        },

                        {
                            name:"Taken_Days",
                            placeholder:"Taken Days",
                            label:"Taken Days",
                            variant:"outlined",
                            fullWidth:true,
                            required:true,
                            
                            xs:12,sm:12,
                            
                            },

                            {
                                name:"Max_Days",
                                placeholder:"Max Days",
                                label:"Max Days",
                                variant:"outlined",
                                fullWidth:true,
                                required:true,
                                
                                xs:12,sm:12,
                                
                                },

                                {
                                    name:"Bal_Days",
                                    placeholder:"Bal Days",
                                    label:"Bal Days",
                                    variant:"outlined",
                                    fullWidth:true,
                                    required:true,
                                    
                                    xs:12,sm:12,
                                    
                                    },

                                    {
                                        name:"Basic_PerDay",
                                        placeholder:"Basic PerDay",
                                        label:"Basic PerDay",
                                        variant:"outlined",
                                        fullWidth:true,
                                        required:true,
                                        
                                        xs:12,sm:12,
                                        
                                        },

                                        {
                                            name:"Total_Amt",
                                            placeholder:"Total Amt",
                                            label:"Total Amt",
                                            variant:"outlined",
                                            fullWidth:true,
                                            required:true,
                                            
                                            xs:12,sm:12,
                                            
                                            },

                {
                    name:"Date",
                    label:"Date",
                    variant:"outlined",
                    fullWidth:true,
                    required:true,
                    
                    xs:12,sm:12,
                    type:"datetime-local",
            inputprops: {
                shrink: true
            }
                },

                {
                    name:"YearEnd",
                    placeholder:"YearEnd",
                    label:"YearEnd",
                    variant:"outlined",
                    fullWidth:true,
                    required:true,
                    
                    xs:12,sm:12,
                    
                    },
                    ]
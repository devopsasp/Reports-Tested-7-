import React from 'react'
import Paycalc from './Payslip';
import { Grid, Button } from '@mui/material';
import generatePDF from 'react-to-pdf';
import { useRef } from 'react';
import Medical from './Medical';
import Esicslip from './Esicslip';
import D7Reports from'./d7Reports';
import PayRegister from './PayRegisterReports';

function Payregister() {
    const targetRef = useRef();
    return (
      <div className="App">
        <div ref={targetRef}>
        < PayRegister/>
        </div>
        <div>
        <Grid item xs={12} textAlign={'center'}>
          <Button variant='outlined' onClick={ ()=> generatePDF(targetRef, {filename: 'PayRegister.pdf'})}>Download Pdf</Button>
          </Grid>
          </div>
     </div>
    );
}

export default Payregister
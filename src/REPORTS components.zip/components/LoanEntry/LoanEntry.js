// export const inputLoanEntryForm= [
//     {
//         name:"PnCompanyId",
//         placeholder:"Enter Company Id ",
//         label:"Company Id",
//         variant:"outlined",
//         fullWidth:true,
//         required:true,
        
//         xs:12,sm:12,
//         select:true, 
//         options: [
//             {value:"1", lable:"Company 1"},
//             {value:"2", lable:"Company 2"}
//         ]
//         },

//         {
//             name:"PnBranchId",
//             placeholder:"Enter Branch Id ",
//             label:"Branch Id",
//             variant:"outlined",
//             fullWidth:true,
//             required:true,
            
//             xs:12,sm:12,
//             select:true, 
//         options: [
//             {value:"1", lable:"Company 1"},
//             {value:"2", lable:"Company 2"}
//         ]
           
//             },
//             {
//                 name:"PnEmployeeId",
//                 placeholder:"Enter Employee Id ",
//                 label:"Employee Id",
//                 variant:"outlined",
//                 fullWidth:true,
//                 required:true,
                
//                 xs:12,sm:12,
               
//                 },
//                 {
//                     name:"Loan_AutoID",
//                     placeholder:"Enter Loan Auto ID ",
//                     label:"Loan Auto Id",
//                     variant:"outlined",
//                     fullWidth:true,
//                     required:true,
                    
//                     xs:12,sm:12,
//                 },

//                 {
//                     name:"fn_LoanID",
//                     placeholder:"Enter Fn Loan ID ",
//                     label:"Fn Loan ID",
//                     variant:"outlined",
//                     fullWidth:true,
//                     required:true,
                    
//                     xs:12,sm:12,
//                     select:true, 
//         options: [
//             {value:"1", lable:"Company 1"},
//             {value:"2", lable:"Company 2"}
//         ]
//                 },

//                 {
//                     name:"san_date",
//                     label:"San Date",
//                     variant:"outlined",
//                     fullWidth:true,
//                     required:true,
                    
//                     xs:12,sm:12,
//                     type:"datetime-local",
//                         inputprops: {
//                             shrink: true
//                         }
//                 },

//                 {
//                     name:"d_effdate",
//                     label:"D Eff Date",
//                     variant:"outlined",
//                     fullWidth:true,
//                     required:true,
                    
//                     xs:12,sm:12,
//                     type:"datetime-local",
//                         inputprops: {
//                             shrink: true
//                         }
//                 },

//                 {
//                     name:"Loan_Amt",
//                     placeholder:"Enter Loan Amount ",
//                     label:"Loan Amount",
//                     variant:"outlined",
//                     fullWidth:true,
//                     required:true,
                    
//                     xs:12,sm:12,
//                 },

//                 {
//                     name:"InstalmentAmt",
//                     placeholder:"Enter Instalment Amount ",
//                     label:"Instalment Amount",
//                     variant:"outlined",
//                     fullWidth:true,
//                     required:true,
                    
//                     xs:12,sm:12,
//                 },

//                 {
//                     name:"Instalmentcount",
//                     placeholder:"Enter Instalment Count ",
//                     label:"Instalment Count",
//                     variant:"outlined",
//                     fullWidth:true,
//                     required:true,
                    
//                     xs:12,sm:12,
//                 },

//                 {
//                     name:"Balance_Amt",
//                     placeholder:"Enter Balance Amount",
//                     label:"Balance Amount",
//                     variant:"outlined",
//                     fullWidth:true,
//                     required:true,
                    
//                     xs:12,sm:12,
//                 },

//                 {
//                     name:"c_status",
//                     placeholder:"Enter C Status",
//                     label:"C Status",
//                     variant:"outlined",
//                     fullWidth:true,
//                     required:true,
                    
//                     xs:12,sm:12,
//                 },

//                 {
//                     name:"loan_name",
//                     placeholder:"Enter loan Name",
//                     label:"loan Name",
//                     variant:"outlined",
//                     fullWidth:true,
//                     required:true,
                    
//                     xs:12,sm:12,
//                 },

//                 {
//                     name:"loan_process",
//                     placeholder:"Enter loan Process",
//                     label:"loan Process",
//                     variant:"outlined",
//                     fullWidth:true,
//                     required:true,
                    
//                     xs:12,sm:12,
//                 },

//                 {
//                     name:"loan_calculation",
//                     placeholder:"Enter Loan Calculation",
//                     label:"Loan Calculation",
//                     variant:"outlined",
//                     fullWidth:true,
//                     required:true,
                    
//                     xs:12,sm:12,
//                 },

//                 {
//                     name:"comments",
//                     placeholder:"Enter Comments",
//                     label:"Comments",
//                     variant:"outlined",
//                     fullWidth:true,
//                     required:true,
                    
//                     xs:12,sm:12,
//                 },

//                 {
//                     name:"loan_appid",
//                     placeholder:"Enter Loan App Id",
//                     label:"Loan App Id",
//                     variant:"outlined",
//                     fullWidth:true,
//                     required:true,
                    
//                     xs:12,sm:12,
//                 },

//                 {
//                     name:"interest",
//                     placeholder:"Enter Interest",
//                     label:"Interest",
//                     variant:"outlined",
//                     fullWidth:true,
//                     required:true,
                    
//                     xs:12,sm:12,
//                 },

//                 {
//                     name:"tot_interest_amt",
//                     placeholder:"Enter Tot Interest Amount",
//                     label:"Tot Interest Amount",
//                     variant:"outlined",
//                     fullWidth:true,
//                     required:true,
                    
//                     xs:12,sm:12,
//                 },

//                 {
//                     name:"emp_name",
//                     placeholder:"Enter Employee Name",
//                     label:"Employee Name",
//                     variant:"outlined",
//                     fullWidth:true,
//                     required:true,
                    
//                     xs:12,sm:12,
//                 },

//                 {
//                     name:"loan_status",
//                     placeholder:"Enter Loan Status",
//                     label:"Loan Status",
//                     variant:"outlined",
//                     fullWidth:true,
//                     required:true,
                    
//                     xs:12,sm:12,
//                 },

//                 {
//                     name:"lasttransaction_from",
//                     placeholder:"Enter Last Transaction From",
//                     label:"Last Transaction From",
//                     variant:"outlined",
//                     fullWidth:true,
//                     required:true,
                    
//                     xs:12,sm:12,
//                     type:"datetime-local",
//                         inputprops: {
//                             shrink: true
//                         }
//                 },

//                 {
//                     name:"lasttransaction_to",
//                     placeholder:"Enter Last Transaction To",
//                     label:"Last Transaction To",
//                     variant:"outlined",
//                     fullWidth:true,
//                     required:true,
                    
//                     xs:12,sm:12,
//                     type:"datetime-local",
//                         inputprops: {
//                             shrink: true
//                         }
//                 },
//             ]
export const inputpaymComputationForm= [
    
    {
        name:"PnCompanyId",
        placeholder:"Enter Company Id ",
        label:"Company Id",
        variant:"outlined",
        fullWidth:true,
        required:true,
        
        xs:12,sm:12,
        
        },

        {
            name:"BranchID",
            placeholder:"Enter Branch Id ",
            label:"Branch Id",
            variant:"outlined",
            fullWidth:true,
            required:true,
            
            xs:12,sm:12,
            
            },

            {
                name:"Type",
                placeholder:"Enter Type ",
                label:"Type",
                variant:"outlined",
                fullWidth:true,
                required:true,
                
                xs:12,sm:12,
                
                },

            {
                name:"pn_EarningsCode",
                placeholder:"Enter pn Earnings Code ",
                label:"pn Earnings Code",
                variant:"outlined",
                fullWidth:true,
                required:true,
                
                xs:12,sm:12,
                },

                {
                    name:"Value",
                    placeholder:"Enter Value ",
                    label:"Value",
                    variant:"outlined",
                    fullWidth:true,
                    required:true,
                    
                    xs:12,sm:12,
                    },

                
                    ]
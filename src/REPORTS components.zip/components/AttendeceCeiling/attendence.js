export const inputFormAttendence = [
    // {
    //     name:"PnCompanyId",
    //     placeholder:"Enter Company Id ",
    //     label:"Company Id",
    //     variant:"outlined",
    //     fullWidth:true,
    //     required:true,
        
    //     xs:12,sm:12,
    //     select:true, 
    //     options: [
    //         {value:"1", lable:"Company 1"},
    //         {value:"2", lable:"Company 2"}
    //     ]
    //     },
    //     {
    //         name:"PnBranchId",
    //         placeholder:"Enter Branch Id ",
    //         label:"Branch Id",
    //         variant:"outlined",
    //         fullWidth:true,
    //         required:true,
            
    //         xs:12,sm:12,
    //         select:true, 
    //         options: [
    //             {value:"1", lable:"Company 1"},
    //             {value:"2", lable:"Company 2"}
    //         ]
    //         },
            {
                name:"intime",
                placeholder:"Enter InTime ",
                label:"In Time",
                variant:"outlined",
                fullWidth:true,
                required:true,
                type: "time",
                xs:12,sm:12
            },
            {
                name:"earlyIntime",
                placeholder:"Enter Early InTime ",
                label:"Early InTime",
                variant:"outlined",
                fullWidth:true,
                required:true,
                type:"time",
                
                xs:12,sm:12
            },
            {
                name:"shiftLin",
                placeholder:"Enter Shift Late Intime",
                label:"Shift Late Intime",
                variant:"outlined",
                fullWidth:true,
                required:true,
                type:"time",
                xs:12,sm:12
            },
           
            {
                name:"lunchEin",
                placeholder:"Enter Lunch Early Intime",
                label:"Shift Lunch Intime",
                variant:"outlined",
                fullWidth:true,
                required:true,
                type:"time",
                xs:12,sm:12
            },
            {
                name:" halfday",
                placeholder:"Enter HalfDay",
                label:"HalfDay",
                variant:"outlined",
                fullWidth:true,
                required:true,
                type:"time",
                xs:12,sm:12
            },
            {
                name:"otLimit",
                placeholder:"Enter ot Limit",
                label:"ot Limit",
                variant:"outlined",
                fullWidth:true,
                required:true,
                type:"time",
                xs:12,sm:12
            },
            {
                name:" permissionLimit",
                placeholder:"Enter Permission Limit",
                label:"Permission Limit",
                variant:"outlined",
                fullWidth:true,
                required:true,
                type:"time",
                xs:12,sm:12
            },
            {
                name:"leaveDays",
                placeholder:"Enter Leave Days",
                label:"Leave Days",
                variant:"outlined",
                fullWidth:true,
                required:true,
                
                xs:12,sm:12
            },
            {
                name:"morningOt",
                placeholder:"Enter Morning ot",
                label:"Morning ot",
                variant:"outlined",
                fullWidth:true,
                required:true,
                
                xs:12,sm:12
            },
            {
                name:"monthType",
                placeholder:"Enter Month Type",
                label:"Month Type",
                variant:"outlined",
                fullWidth:true,
                required:true,
                xs:12,sm:12
            },
            {
                name:"weekOff1",
                placeholder:"Enter Weak Off1",
                label:"Weak Off1",
                variant:"outlined",
                fullWidth:true,
                required:true,
                
                xs:12,sm:12
            },
            {
                name:" weekOff2",
                placeholder:"Enter Weak Off2",
                label:"Weak Off2",
                variant:"outlined",
                fullWidth:true,
                required:true,
                
                xs:12,sm:12
            },

            {
                name:"manualDays",
                placeholder:"Enter Manual Days",
                label:"Manual Days",
                variant:"outlined",
                fullWidth:true,
                required:true,
                
                xs:12,sm:12
            },
            {
                name:"otDays",
                placeholder:"Enter ot Days",
                label:"ot Days",
                variant:"outlined",
                fullWidth:true,
                required:true,
                
                xs:12,sm:12
            },

            {
                name:"otHrs",
                placeholder:"Enter ot Hours",
                label:"ot Hours",
                variant:"outlined",
                fullWidth:true,
                required:true,
                
                xs:12,sm:12
            },

            {
                name:"timeCard",
                placeholder:"Enter Time card",
                label:"Time card",
                variant:"outlined",
                fullWidth:true,
                required:true,
                
                xs:12,sm:12
            },

            {
                name:"ptaxMonth",
                placeholder:"Enter Proffessionl Tax Month",
                label:"ot Hours",
                variant:"outlined",
                fullWidth:true,
                required:true,
                
                xs:12,sm:12
            },
            {
                name:"  readerName",
                placeholder:"Enter Reader Name",
                label:"Reader Name",
                variant:"outlined",
                fullWidth:true,
                required:true,
                
                xs:12,sm:12
            },
            
    ]